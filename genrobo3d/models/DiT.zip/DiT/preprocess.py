import torch

def padding(max_steps, batch, batch_size, robot_type, device):

    gt_joints = batch.get('gt_joints', None)
    gt_actions = batch.get('gt_actions', None)
    
    # Define padding of gt_actions, mask, step_ids
    pad_gt_traj = torch.zeros((batch_size, max_steps, robot_type), device=device)
    pad_mask = torch.zeros((batch_size, max_steps,), dtype=torch.bool, device=device)

    step_ids = batch['step_ids'] 

    start_indices = (batch['step_ids'] == 0).nonzero(as_tuple=True)[0]
    end_indices = start_indices[1:] - 1
    last_index = torch.tensor([len(batch['step_ids']) - 1], device=batch['step_ids'].device)
    end_indices = torch.cat([end_indices, last_index]) 
    gt_trajs = torch.hstack([gt_joints, gt_actions[:, -1:]])
    pad_gt_traj = gt_trajs[end_indices].unsqueeze(1).expand(-1, max_steps, -1).clone()

    task_ids = torch.cumsum(torch.cat([
                torch.tensor([1], device=step_ids.device),
                (step_ids[1:] == 0).int()
            ]), dim=0) - 1
    
    for i in range(gt_actions.shape[0]):  # N = total number of steps (task*steps)
        task = int(task_ids[i].item())
        step = int(step_ids[i].item())
        pad_gt_traj[task, step] = torch.cat([gt_joints[i], gt_actions[i][-1].unsqueeze(0)], dim=0)
        pad_mask[task, step] = True

    return pad_gt_traj, pad_mask

def rescale(traj, mode='norm'):
    # Min and max joint limits
    joint_mins = torch.tensor([-2.8973, -1.7628, -2.8973, -3.0718, -2.8973, -0.0175, -2.8973], 
                            dtype=traj.dtype, device=traj.device)
    joint_maxs = torch.tensor([ 2.8973,  1.7628,  2.8973, -0.0698,  2.8973,  3.7525,  2.8973], 
                            dtype=traj.dtype, device=traj.device)

    # Extract joints and open components
    joints = traj[..., :-1]   # Shape: (batch, max_steps, 7)
    gripper = traj[..., -1]  # Shape: (batch, max_steps)

    if mode == 'norm':
        # Normalize joints to [-1, 1]
        joints = 2 * (joints - joint_mins) / (joint_maxs - joint_mins) - 1
        # Normalize gripper to [-1, 1] (assuming it was in [0, 1])
        gripper = gripper * 2 - 1

    elif mode == 'real':
        joints = 0.5 * (joints + 1) * (joint_maxs - joint_mins) + joint_mins

    else:
        AssertionError('wrong mode, rescale trajectory value between norm or real')


    # Reconstruct normalized trajectory
    traj = torch.cat([joints, gripper.unsqueeze(-1)], dim=-1)   # Shape: (batch, max_steps, 8)

    return traj